
class ObsidionToolLaunchAdapterRegistry:

    def __init__(self):
        self.adapters = {
            "AssetVault": "AssetVaultSystem",
            "WorldEditor": "WorldEditorSystem",
            "SceneTools": "SceneToolsSystem",
            "Renderer": "RealmRendererSystem",
            "ViewportCamera": "ViewportCameraSystem",
            "RealmPreview": "RealmPreviewSystem",

            "BuildErrorReports": "BuildErrorReportSystem",
            "Reports": "ReportSystem",
            "Audits": "AuditSystem",
            "Root Cause": "RootCauseAnalysisSystem",
            "Mission Control": "MissionControlSystem",
            "RuntimeLogs": "RuntimeLogSystem"
        }

    def status(self):
        return "TOOL LAUNCH ADAPTER REGISTRY ONLINE"

    def launch_target(self, tool):
        return self.adapters.get(tool, "NO ADAPTER FOUND")

    def available_adapters(self):
        return self.adapters

    def client_runtime_request(
        self,
        client_id,
        runtime_target,
        working_directory=None,
        arguments=None,
    ):
        return {
            "adapter": "CLIENT_RUNTIME",
            "client_id": client_id,
            "runtime_target": runtime_target,
            "working_directory": working_directory,
            "arguments": list(arguments or []),
        }

